#!/bin/sh

# to fetch the log file
curl https://pastebin.com/raw/gstGCJv4 -o access_ssl.log

# find how many line that contain the route and save it in a file
grep -nr '/production/file_metadata/modules/ssh/sshd_config' access_ssl.log > resultSSHD_config.log

grep -nr '200' resultSSHD_config.log > resultSSHD_config_200.log
totalNumberGet=$(wc -l < resultSSHD_config.log)
totalNumberGet200=$(wc -l < resultSSHD_config_200.log)
totalNot200=$((totalNumberGet - totalNumberGet200))

#find total numbers of line in the file
totalNumberInFile=$(wc -l < access_ssl.log)
#get number of lines that contain 200 in full log
grep -nr '200' access_ssl.log > resultGet200InFullLog.log
totalNumber200InFile=$(wc -l < resultGet200InFullLog.log)
totalNot200InFullLog=$((totalNumberInFile - totalNumber200InFile))

grep -nr '/dev/report' access_ssl.log > resultDevReport.log 

totalDevReport=$(wc -l < resultDevReport.log)

echo "the URL /production/file_metadata/modules/ssh/sshd_config was fetched "$totalNumberGet "times"

echo "In the previous request, the time that apache didn't return a code 200 is "$totalNot200 "times"

echo "the total number of times that apache returned any code other than 200 is "$totalNot200InFullLog "times"

echo "the total number of times that any IP address sent a PUT  request under the path /dev/report is " $totalDevReport "times"
